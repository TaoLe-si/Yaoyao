# Engram-Rule 离线解码器

**基准**：d=128 / 400 步 / 1,651,258 参数 / 6.644 MB 权重
（对应 `../DESIGN.md` §64.8 的定档基准）

## 这个包是什么

一个**自包含**的推理包：把基准权重 + tokenizer + 解码器打在一起，
**不需要** `engram_rule` 仓库的任何其他文件，也不需要 `train.py`。

生成走的是**出货的** `greedy_generate`（`dialogue_small.py` 里那份），
不是重写的循环 —— 这份解码器已被 §51 的 18 项等价性判据（`check_fast_path_equiv.py`）看守。

## 依赖

| 包 | 用途 | 必须 |
|---|---|---|
| `torch` | 推理 | **是** |
| `tokenizers` | 载入 BPE tokenizer | **是** |

不需要 `requests`（那只用于下载语料）、不需要 `train.py`（那只用于训练与存档）——
精简副本里已去掉这两处 import，其余代码**逐字未改**。

## 用法

```bash
# 交互模式(每行一个问题, 空行退出)
python decode.py

# 单次提问
python decode.py "你最喜欢的食物是什么？"

# 一次多问(自动走等长分组批生成)
python decode.py "你最喜欢的食物是什么？" "今天天气如何？"

# 从文件批量(一行一问)
python decode.py --file questions.txt

# 只打印权重信息
python decode.py --info

# 速度基准(64 行批生成)
python decode.py --bench

# 指定权重 / 设备
python decode.py --ckpt path/to/other.pt --device cpu "问题"
```

## 实测

| 项 | 读数 |
|---|---|
| 载入耗时 | **0.2 s**（CUDA）/ 0.0 s（CPU） |
| 单问延迟 | **1.56 s**（CPU，首问含预热） |
| 批生成 | **0.013 s/行**（64 行 0.8 s，CUDA） |
| EOS 率 | 1.00 |
| 隔离验证 | 拷到临时目录、脱离原仓库运行 → **returncode 0** |

★**CPU 也能跑**（`--device cpu`，1.56 s/问）。CUDA 只是更快。

## 解码参数（与 §64 基准一致）

- `greedy`（`temperature=0.0`）
- `max_new_tokens = 400`（§60.5 口径修正：语料 gold_len 最大 366，设 90 会白丢 11.6% 样本）
- `context_limit = 512`（checkpoint 的 `sequence_length`）
- `utf8_safe = True`（ByteLevel 允许集，保证不会吐出半个汉字）
- `repetition_penalty = 1.0`、`no_repeat_ngram = 0`（出货默认，未加任何约束）

## 文件清单

| 文件 | 大小 | 说明 |
|---|---:|---|
| `engram_rule_dialogue_bpe_answer_disjoint_d128_s11_st400.pt` | 6.336 MB | 权重 + cfg + tokenizer |
| `model.py` | 0.041 MB | 模型定义，**逐字拷贝** |
| `dialogue_small.py` | 0.086 MB | 解码器，**去掉 3 行 import，其余逐字** |
| `decode.py` | 0.005 MB | CLI 入口 |
| `README.md` | — | 本文件 |

## 已知边界

- 这是**训练集上**做到 EM 0.96 / char-F1 0.9931 的模型（§64）。
  **留出集（eval）上它基本答不对** —— §56.6 实测 d=64→128 时 eval `gen_em` 恒为 0/204。
  若用在没见过的数据上，预期它会退回到"按句式模板生成"。
- 单 seed（seed=11），无种子极差。
- 权重里**不含** `raw_dialogue_rows`（那份在 `../archive/engram_rule_dialogue_bpe_answer_disjoint_d128_s11.pt`）。
